package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.OpticalDistanceSensor;
import com.qualcomm.robotcore.hardware.TouchSensor;
import com.qualcomm.robotcore.hardware.Blinker;

@TeleOp(name = "Tele-Op Holo")

public class TestHolo extends LinearOpMode {

    private DcMotor motor1 = null;
    private DcMotor motor2 = null;
    private DcMotor motor3 = null;
    private DcMotor motor4 = null;
    private DcMotor motor5 = null; //slide control right
    private DcMotor motor6 = null; //slide control left
    public Servo rightClaw = null;

    double clawOffset = 0;

    public static final double MID_SERVO   =  0.4;
    public static final double CLAW_SPEED  = 0.002;        // sets rate to move servo
    
    @Override
    public void runOpMode() {
        
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        
        motor1 = hardwareMap.get(DcMotor.class,"front left"); //frontleft, port 0
        motor2 = hardwareMap.get(DcMotor.class,"front right");  //frontright, port 1
        motor3 = hardwareMap.get(DcMotor.class,"back left"); //backleft, port 3
        motor4 = hardwareMap.get(DcMotor.class,"back right");  //backright, port 2
        motor5 = hardwareMap.get(DcMotor.class, "slide right");
        motor6 = hardwareMap.get(DcMotor.class, "slide left");
        rightClaw = hardwareMap.get(Servo.class, "right claw");
        
        rightClaw.setPosition(MID_SERVO);
        
        motor1.setDirection(DcMotor.Direction.FORWARD);
        motor2.setDirection(DcMotor.Direction.REVERSE);
        motor3.setDirection(DcMotor.Direction.FORWARD);
        motor4.setDirection(DcMotor.Direction.REVERSE);
        
        waitForStart();

        while (opModeIsActive()) {
            
            double forwardMotion;
            double horizonMotion;
            double rotateMotion;
            
            forwardMotion = -gamepad1.right_stick_y;
            horizonMotion = gamepad1.right_stick_x*1.1;
            rotateMotion = -gamepad1.left_stick_x;
          
            double denominator = Math.max(Math.abs(forwardMotion) + Math.abs(horizonMotion) + Math.abs(rotateMotion), 1);
            double m1Power = (rotateMotion - forwardMotion - horizonMotion) / denominator;
            double m2Power = (-rotateMotion - forwardMotion + horizonMotion) / denominator;
            double m3Power = (rotateMotion - forwardMotion + horizonMotion) / denominator;
            double m4Power = (-rotateMotion - forwardMotion - horizonMotion) / denominator;
            double m5Power = gamepad2.right_stick_y;
            double m6Power = -gamepad2.right_stick_y;
            
           if (m5Power >= 0.38) {
                motor1.setPower(m1Power/4);
                motor2.setPower(m2Power/4);
                motor3.setPower(m3Power/4);
                motor4.setPower(m4Power/4);
           } else {
                motor1.setPower((m1Power*.75));
                motor2.setPower((m2Power*.75));
                motor3.setPower((m3Power*.75));
                motor4.setPower((m4Power*.75));
           }
           
            motor5.setPower(m5Power);
            motor6.setPower(m6Power);
            
            if (gamepad2.right_bumper) 
            clawOffset += CLAW_SPEED;
             else if (gamepad2.left_bumper) 
            clawOffset -= CLAW_SPEED;
             else clawOffset = clawOffset;
            
            clawOffset = Range.clip(clawOffset, -0.19, 0.17);
            rightClaw.setPosition(MID_SERVO - clawOffset);
            
            telemetry.addData("m1:", m1Power);            
            telemetry.addData("m2:", m2Power);
            telemetry.addData("m3:", m3Power);
            telemetry.addData("m4:", m4Power);
            telemetry.addData("m5:", m5Power);
            telemetry.addData("m6:", m6Power);
            telemetry.addData("FM:", forwardMotion);
            telemetry.addData("HM:", horizonMotion);
            telemetry.addData("RM:", rotateMotion);
            telemetry.addData("claw",  "Offset = %.2f", clawOffset);
            telemetry.addData("Slide Pos:", m6Power+m5Power);
            telemetry.addData("Status", "Running");
            telemetry.update();

        }
    }
}
